package ifsc.eng.Lab_Ana_BCD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabAnaBcdApplicationTests {

	@Test
	void contextLoads() {
	}

}
